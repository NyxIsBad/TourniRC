TourniRC portable Windows distribution

1. Extract the entire TourniRC directory from the ZIP.
2. Run TourniRC.exe and leave its terminal window open.
3. Navigate to http://localhost:5000 in your browser.
4. Press Ctrl+C or close the terminal to stop TourniRC.

Your login, settings, uploaded sounds, tournament presets, and diagnostic logs
are written beside the executable under cfg\ and logs\. Do not run the app
directly from inside the ZIP.
